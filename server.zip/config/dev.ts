import {Config} from '@kaishen/sagittarius';

export default class Dev extends Config {
    async init(): Promise<void> {
        return new Promise(async (resolve, reject) => {
            this.env = 'dev';
            this.port = 3000;
            this.logs = {
                type: 'console',
                level: 'TRACE',
            };
            this.error = {
                5000: '后端服务器异常',
                5100: '数据库操作异常',
            };
            resolve();
        })
    }
}
