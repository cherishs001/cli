require('module-alias/register');

import { Sagittarius } from '@kaishen/sagittarius';

const app = Sagittarius.app;

process.on('uncaughtException', (e) => {
    console.error('process error is:', e.message);
    process.exit(-1);
});
process.on('unhandledRejection', (e) => {
    console.error('process error is:', e);
    process.exit(-1);
});

module.exports = (async () => {
    return await app.listen((env) => {
        console.log(`listen ${env.port} port`);
    });
})();
