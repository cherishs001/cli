import { Context, Orm, Schema, Service, Fetch } from '@kaishen/sagittarius';

export default class AmortisationPrice extends Service {
    path: string = '/v1/hello';

    async GET(ctx: Context): Promise<void> {
        ctx.info = `hello world`;
        ctx.body = {};
    }
}
